<?php include("sidebar.php");
 ?>
<div class="page-content container-fluid">
    <div class="footer">
        <div class="d-flex justify-content-center">
             <h2 class="" style=" font-weight: 600">Dashboard </h2>
        </div>
        <hr style="margin: 0px;">
    </div>
</div>



<!-- sidebar-wrapper  -->
<main class="page-content">
    <div class="container-fluid">
        <div class="row d-flex . justify-content-center">
            <div class="count_stortcut bg-success">
                <div class="row">
                    <div class="col-md-3 col-4">
                        <h1 class="m-2">
                    </div>
                    <div class="col-md-3 offset-4">
                        <i class="fas fa-teacher fa-3x m-2"></i>
                    </div>
                </div>
                <div class="header_msg text-center">Online Orders</div>
            </div>
        </div>
        <div class="row d-flex . justify-content-center">
            <div class="count_stortcut" style="background-color:#B3B54C;">
                <div class="row">
                    <div class="col-md-3 col-4">
                        <h1 class="m-2">
                    </div>
                    <div class="col-md-3 offset-4">
                        <i class="fas fa-user-graduate fa-3x m-2"></i>
                    </div>
                </div>
                <div class="header_msg text-center">Counter Orders</div>
            </div>
        </div>
        <div class="row d-flex . justify-content-center">
            <div class="count_stortcut "style="background-color:#CEC46A;">
                <div class="row">
                    <div class="col-md-3 col-4">
                        <h1 class="m-2">
                    </div>
                    <div class="col-md-3 offset-4">
                        <i class="fas fa-teacher fa-3x m-2"></i>
                    </div>
                </div>
                <div class="header_msg text-center">Counter Underprocessing</div>
            </div>
        </div>
        <div class="row d-flex . justify-content-center">
            <div class="count_stortcut " style="background-color:#625A11;">
                <div class="row">
                    <div class="col-md-3 col-4">
                    <h1 class="m-2">
                    </div>
                    <div class="col-md-3 offset-4">
                        <i class="fas fa-teacher fa-3x m-2"></i>
                    </div>
                </div>
                <div class="header_msg text-center">Counter Completed</div>
            </div>
        </div>
    </div>
    <hr />

    

    
</main>
<?php include('../footer.php'); ?>

</div>



</body>

</html>
